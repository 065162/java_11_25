#include <stdio.h>
int main(void)
{
    int sum=10;
    int a[]={1,2,3,4,5,6,7,8};
    for(int i=0;i<=7;i++){
        for(int j=0;j<=7;j++){
            if(a[i]+a[j]==sum)
            printf("%d,%d",i,j);
            break;
        }
    }
}