//6位评委去掉最高分和最低分后的平均分
import java.util.Scanner;
public class test3 {
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        int Fraction[]=new int[6];
        for(int i=0;i<6;i++){
            Fraction[i]=sc.nextInt();
        }
        int sum=0;
        int max=Fraction[0],min=Fraction[0];
        for(int j=0;j<6;j++){
            if(Fraction[j]>max){
                max=Fraction[j];
            } 
            if(Fraction[j]<min){
                min=Fraction[j];
            }    
        }
        for(int i=0;i<6;i++){
            if(Fraction[i]!=max){
                if(Fraction[i]!=min){
                    sum=sum+Fraction[i];
                }
            }
        }
        System.out.println(sum/4);
    }
}
