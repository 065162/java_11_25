//根据月份判断飞机票打折情况
import java.util.Scanner;
public class test1 {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("请输入机票原价");
        int pal=sc.nextInt();
        System.out.println("请问您几月份坐飞机呢？");
        int month=sc.nextInt();
        System.out.println("头等舱请输入1，经济舱请输入2");
        int cang=sc.nextInt();
        howmuch(pal, month, cang);
        
    }
    public static void howmuch(int pal,int month,int cang){
        if(month>=5&&month<=10){
            if(cang==1){
                System.out.println("9折"+pal*0.9);
            }else if(cang==2){
                System.out.println("8.5折"+pal*0.85);
            }
        }else {
            if(cang==1){
                System.out.println("7折"+pal*0.7);
            }else if(cang==2){
                System.out.println("6.5折"+pal*0.65);
            }
    
        }
    }

}
