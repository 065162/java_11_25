//数字加密，四位数，每一位单独+5然后对10取模
import java.util.Scanner;
public class test4 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int Password[]=new int[4];
        int Password1[]=new int[4];
        int Password2[]=new int[4];
        for(int i=0;i<Password.length;i++){
            Password[i]=sc.nextInt();
        }
        System.out.println("\n");
        for(int i=0;i<4;i++){
            Password1[i]=(Password[i]+5)%10;
        }
        for (int i = 0; i < Password2.length; i++) {
            Password2[i]=Password1[3-i];
        }
        for (int i = 0; i < Password2.length; i++) {
            System.out.print(Password2[i]+"");
        }
        //从这里开始，用Pass2去求出pass1
        int Password3[]=new int[4];
        int Password4[]=new int[4];
        for (int i = 0; i < Password3.length; i++) {
            Password3[i]=Password2[3-i];
        }
        for (int i = 0; i < Password4.length; i++) {
            if(Password3[i]>5){
                Password4[i]=(Password3[i])-5;
            }else if(Password3[i]<5){
                Password4[i]=(Password3[i]+10)-5;
            }
            
            
            
        }
        System.out.println("\n"+"\n还原了");
        for (int i = 0; i < Password4.length; i++) {
            System.out.print(Password4[i]+"");
        }
        

    }
}
