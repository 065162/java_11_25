public class demo {
    public static void main(String[] args) {
        char[] zimu=new char[52];
        for (int i = 0; i < zimu.length; i++) {
            zimu[i]= (char)(65+i);
        }
        for (int i = 0; i < zimu.length; i++) {
            System.out.println(zimu[i]);
        }
    }
}
