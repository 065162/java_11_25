//项目  利用方copy数组
public class test2{
    public static void main(String[] args) {
       int arr[]={1,2,3,4,5,6,7,8,9};
       int newarr[]=copy(arr, 2, 8);
    //    for (int i = 0; i < copy(arr, 1, 3).length; i++) {
    //         System.out.println(copy(arr, 1, 3)[i]);
    //    }
       for (int i = 0; i < newarr.length; i++) {
        System.out.println(newarr[i]);
       }
    }
    public static int[] copy(int arr[],int from,int to){
        
        int length=to-from;
        int newarr[]=new int[length];
        int j=0;
        for (int i = from; i < to; i++,j++) {
            newarr[j]=arr[i];
        }
        return newarr;
    }
}