public class dome2 {
public static void main(String[] args) {
    Math.pow(10,0);
}
}
