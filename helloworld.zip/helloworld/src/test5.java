//生成随机数验证码（前四位为随机大小写字母，最后一位为数字）
import java.util.Random;
public class test5 {
    public static void main(String[] args){
        char[] ra=random__();
        for (int i = 0; i < ra.length; i++) {
            System.out.print(ra[i]);
        }
    }
    public static char[] random__(){
        char[] zimu={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
        char[] shuzi={'0','1','2','3','4','5','6','7','8','9'};
        Random random=new Random();
        int a1=random.nextInt(53);
        int a2=random.nextInt(53);
        int a3=random.nextInt(53);
        int a4=random.nextInt(53);
        int a5=random.nextInt(10);
        char[] ran=new char[5];
        ran[0]=zimu[a1];
        ran[1]=zimu[a2];
        ran[2]=zimu[a3];
        ran[3]=zimu[a4];
        ran[4]=shuzi[a5];
        return ran;
    }

}
