public class test6 {
    public static void main(String[] args) {
        
    }
}
